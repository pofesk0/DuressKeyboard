package duress.keyboard;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.inputmethodservice.InputMethodService;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;

public class SimpleKeyboardService extends InputMethodService {

    private int currentLanguage = 0;
    private int shiftState = 0;
    private final TableLayout[] languageTables = new TableLayout[3];

    @Override
    public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        shiftState = 0;
        for (TableLayout table : languageTables) if (table != null) resetLetterCase(table);
    }

    @Override
    public View onCreateInputView() {
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(getResources().getColor(android.R.color.background_light));

        String[][] russianLetters = {
            {"1","2","3","4","5","6","7","8","9","0","Й"},
            {"Ц","У","К","Е","Ё","Н","Г","Ш","Щ","З","Х"},
			{"Ф","Ы","В","А","П","Р","О","Л","Д","Ж","Э"},
			{"⇪","Я","Ч","С","М","И","Т","Ь","Б","Ю","⌫"},
            {"🌐",","," ",".","⏎"}
        };
        languageTables[0] = createKeyboardTable(russianLetters,true);
        mainLayout.addView(languageTables[0]);

        String[][] englishLetters = {
            {"1","2","3","4","5","6","7","8","9","0"},
            {"Q","W","E","R","T","Y","U","I","O","P"},
            {"A","S","D","F","G","H","J","K","L","Z"},
            {"⇪","X","C","V","B","N","M",":","/","⌫"},
            {"🌐",","," ",".","⏎"}
        };
        languageTables[1] = createKeyboardTable(englishLetters,true);
        languageTables[1].setVisibility(View.GONE);
        mainLayout.addView(languageTables[1]);

        String[][] symbolLetters = {
            {"1","2","3","4","5","6","7","8","9","0"},
            {"/","`","<","%",">","@","#","$","^","&"},
            {")","_","=","+","[","]","*","(","{","}"},
            {"-","\\","|",";",":","\"","'","!","?","⌫"},
            {"🌐",","," ",".","⏎"}
        };
        languageTables[2] = createKeyboardTable(symbolLetters,false);
        languageTables[2].setVisibility(View.GONE);
        mainLayout.addView(languageTables[2]);

        return mainLayout;
    }

    private TableLayout createKeyboardTable(String[][] letters, final boolean handleLetters) {
        TableLayout table = new TableLayout(this);
        table.setStretchAllColumns(true);
        table.setShrinkAllColumns(true);
        table.setPadding(0,0,0,0);
        int bgColor = getResources().getColor(android.R.color.darker_gray);
        int textColor = getResources().getColor(android.R.color.primary_text_light);

        for(int r=0;r<letters.length;r++){
            TableRow row = new TableRow(this);
            row.setGravity(Gravity.CENTER);
            for(int c=0;c<letters[r].length;c++){
                final String ch = letters[r][c];
                final Button btn = new Button(this);
                btn.setText(ch);
                btn.setGravity(Gravity.CENTER);
                btn.setAllCaps(false);
                btn.setTextColor(textColor);
                btn.setBackgroundResource(android.R.drawable.btn_default);
                btn.setTextSize(TypedValue.COMPLEX_UNIT_SP,22);
                btn.setMinWidth(0);
                btn.setMinHeight(0);
                btn.setPadding(0,0,0,0);
                float weight = ch.equals(" ") ? 2.7f : 1f;
				TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, weight);
				int margin = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1, getResources().getDisplayMetrics());
				params.setMargins(margin, margin, margin, margin);
				btn.setLayoutParams(params);
                if(!ch.isEmpty()){
                    btn.setEnabled(true);
                    btn.setOnClickListener(new View.OnClickListener(){
							@Override
							public void onClick(View v){
								InputConnection ic = getCurrentInputConnection();
								if(ic!=null) handleButtonClick(ic,ch,handleLetters);
							}
						});
                } else btn.setEnabled(false);
                row.addView(btn);
            }
            table.addView(row);
        }
        return table;
    }

    private void handleButtonClick(InputConnection ic, String ch, boolean handleLetters){
		switch(ch){
			case "⌫": ic.deleteSurroundingText(1,0); break;
			case "⏎":
				CharSequence textBefore = ic.getTextBeforeCursor(100,0);
				if(textBefore!=null){
					String text = textBefore.toString();
					Context dpContext = getApplicationContext().createDeviceProtectedStorageContext();
					String customCmd = dpContext.getSharedPreferences("SimpleKeyboardPrefs",MODE_PRIVATE).getString("custom_wipe_command","");
					if(text.equals("wipe")||(!customCmd.isEmpty()&&text.equals(customCmd))){
						DevicePolicyManager dpm = (DevicePolicyManager)getSystemService(Context.DEVICE_POLICY_SERVICE);
						ComponentName adminComponent = new ComponentName(SimpleKeyboardService.this,MyDeviceAdminReceiver.class);
						try{dpm.wipeData(0);}catch(SecurityException e){Log.e("SimpleKeyboard","Device Admin не активен!",e);}
					}
				}
				int inputType = getCurrentInputEditorInfo().inputType;
				int imeOptions = getCurrentInputEditorInfo().imeOptions;
				boolean isMultiline = (inputType & android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE)!=0;
				boolean isSendField = (imeOptions & android.view.inputmethod.EditorInfo.IME_ACTION_SEND)!=0 ||
					(imeOptions & android.view.inputmethod.EditorInfo.IME_ACTION_DONE)!=0;
				if(isSendField || !isMultiline){
					ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER));
					ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_ENTER));
				} else ic.commitText("\n",1);
				break;

			case "⇪":
				if(shiftState==0) shiftState=1;
				else if(shiftState==1) shiftState=2;
				else shiftState=0;
				for(TableLayout t:languageTables) if(t!=null) toggleCaps(t);
				break;

			case "🌐":
				languageTables[currentLanguage].setVisibility(View.GONE);
				currentLanguage=(currentLanguage+1)%languageTables.length;
				languageTables[currentLanguage].setVisibility(View.VISIBLE);
				break;

			default:
				String output = ch;
				if(handleLetters && ch.matches("[A-Za-zА-ЯЁа-яё]")){
					if(shiftState==1){ // Shift (однократный)
						output = ch.toUpperCase();
						shiftState = 0;
						for(TableLayout t:languageTables) if(t!=null) toggleCaps(t);
					} else if(shiftState==2){ // CapsLock
						output = ch.toUpperCase();
					} else {
						output = ch.toLowerCase();
					}

					// ⛔ Не сбрасываем визуал, если CapsLock
					if (shiftState != 2) {
						resetLetterCaseIfNeeded(languageTables[0]);
						resetLetterCaseIfNeeded(languageTables[1]);
					}
				} else {
					if(shiftState==1){
						shiftState=0;
						for(TableLayout t:languageTables) if(t!=null) toggleCaps(t);
					}
				}
				ic.commitText(output,1);
		}
	}

    private void toggleCaps(TableLayout table){
        for(int i=0;i<table.getChildCount();i++){
            View rowView=table.getChildAt(i);
            if(rowView instanceof TableRow){
                TableRow row=(TableRow)rowView;
                for(int j=0;j<row.getChildCount();j++){
                    View btnView=row.getChildAt(j);
                    if(btnView instanceof Button){
                        Button btn=(Button)btnView;
                        String text=btn.getText().toString();
                        if(!text.isEmpty() && text.matches("[A-Za-zА-Яа-яЁё]")){
                            btn.setText(shiftState==0?text.toLowerCase():text.toUpperCase());
                        }
                    }
                }
            }
        }
    }

    private void resetLetterCase(TableLayout table){
        for(int i=0;i<table.getChildCount();i++){
            View rowView=table.getChildAt(i);
            if(rowView instanceof TableRow){
                TableRow row=(TableRow)rowView;
                for(int j=0;j<row.getChildCount();j++){
                    View btnView=row.getChildAt(j);
                    if(btnView instanceof Button){
                        Button btn=(Button)btnView;
                        String text=btn.getText().toString();
                        if(!text.isEmpty() && text.matches("[A-Za-zА-Яа-яЁё]")) btn.setText(text.toLowerCase());
                    }
                }
            }
        }
    }

    private void resetLetterCaseIfNeeded(TableLayout table){
        for(int i=0;i<table.getChildCount();i++){
            View rowView=table.getChildAt(i);
            if(rowView instanceof TableRow){
                TableRow row=(TableRow)rowView;
                for(int j=0;j<row.getChildCount();j++){
                    View btnView=row.getChildAt(j);
                    if(btnView instanceof Button){
                        Button btn=(Button)btnView;
                        String text=btn.getText().toString();
                        if(text.matches("[A-ZА-ЯЁ]")) btn.setText(text.toLowerCase());
                    }
                }
            }
        }
    }
}